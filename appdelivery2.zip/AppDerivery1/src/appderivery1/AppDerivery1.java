
package appderivery1;


import guiall.LoginSignup;



/**
 *
 * @author phadol
 */
public class AppDerivery1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
             
    new LoginSignup().setVisible(true);
}
}
