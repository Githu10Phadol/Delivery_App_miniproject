
package appderivery1;

import guiall.A1login;



public class AppDerivery1 {

 
    public static void main(String[] args) {
            
            A1login login = new A1login();
            login.setVisible(true);
                    
                    
    }
}
