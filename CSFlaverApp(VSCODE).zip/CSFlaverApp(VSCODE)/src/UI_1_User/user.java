/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UI_1_User;

/**
 *
 * @author titan
 */
public class user {
    private static user instance;
    private String username;
    private String password;
    private String email;
    private String mobileNumber;
    
    private user() {}
    
    public static user getInstance() {
        if (instance == null) {
            instance = new user();
        }
        return instance;
    }
    
    public void setUserData(String username, String password, String email, String mobileNumber) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.mobileNumber = mobileNumber;
    }
    
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getEmail() { return email; }
    public String getMobileNumber() { return mobileNumber; }
    
    public void clearSession() {
        username = null;
        password = null;
        email = null;
        mobileNumber = null;
    }
    
    public boolean isLoggedIn() {
        return username != null;
    }
}
