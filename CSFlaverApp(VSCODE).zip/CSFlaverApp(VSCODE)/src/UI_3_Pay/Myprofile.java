
package UI_3_Pay;

import UI_2_Menu.rice;
import UI_1_User.user;

public class Myprofile extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Myprofile.class.getName());

    
    public Myprofile() {
        initComponents();
        loadUserProfile();
    }
    
    private void loadUserProfile() {
        user session = user.getInstance();
        
        if (session.isLoggedIn()) {
            LabelUser.setText(session.getUsername());
            LabelEmail.setText(session.getEmail());
            LabelMobile.setText(session.getMobileNumber());
        } else {
            LabelUser.setText("Not found");
            LabelEmail.setText("Not found");
            LabelMobile.setText("Not found");
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        myprofile = new javax.swing.JLabel();
        information = new javax.swing.JLabel();
        username = new javax.swing.JLabel();
        email = new javax.swing.JLabel();
        mobile = new javax.swing.JLabel();
        back = new javax.swing.JButton();
        LabelMobile = new javax.swing.JLabel();
        LabelUser = new javax.swing.JLabel();
        LabelEmail = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1280, 720));
        setResizable(false);
        setSize(new java.awt.Dimension(1280, 720));

        jPanel1.setBackground(new java.awt.Color(206, 215, 209));
        jPanel1.setPreferredSize(new java.awt.Dimension(1280, 720));
        jPanel1.setLayout(null);

        myprofile.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        myprofile.setText("My Profile");
        jPanel1.add(myprofile);
        myprofile.setBounds(525, 50, 243, 58);

        information.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        information.setText("Information");
        jPanel1.add(information);
        information.setBounds(110, 130, 219, 44);

        username.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        username.setText("Username : ");
        jPanel1.add(username);
        username.setBounds(220, 250, 143, 29);

        email.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        email.setText("Email : ");
        jPanel1.add(email);
        email.setBounds(275, 347, 89, 29);

        mobile.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        mobile.setText("Mobile number : ");
        jPanel1.add(mobile);
        mobile.setBounds(163, 440, 201, 29);

        back.setBackground(new java.awt.Color(204, 204, 204));
        back.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/Back (4).png"))); // NOI18N
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        jPanel1.add(back);
        back.setBounds(50, 30, 18, 30);

        LabelMobile.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        LabelMobile.setText("LabelMobile");
        jPanel1.add(LabelMobile);
        LabelMobile.setBounds(410, 435, 390, 40);

        LabelUser.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        LabelUser.setText("LabelUser");
        LabelUser.setMaximumSize(new java.awt.Dimension(143, 29));
        jPanel1.add(LabelUser);
        LabelUser.setBounds(410, 245, 390, 40);

        LabelEmail.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        LabelEmail.setText("LabelEmail");
        LabelEmail.setMaximumSize(new java.awt.Dimension(143, 29));
        jPanel1.add(LabelEmail);
        LabelEmail.setBounds(410, 343, 390, 40);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        rice ricePage = new rice();
        ricePage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backActionPerformed

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel LabelEmail;
    private javax.swing.JLabel LabelMobile;
    private javax.swing.JLabel LabelUser;
    private javax.swing.JButton back;
    private javax.swing.JLabel email;
    private javax.swing.JLabel information;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel mobile;
    private javax.swing.JLabel myprofile;
    private javax.swing.JLabel username;
    // End of variables declaration//GEN-END:variables
}
