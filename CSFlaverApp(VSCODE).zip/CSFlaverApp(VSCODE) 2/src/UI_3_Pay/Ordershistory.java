package UI_3_Pay;

import UI_2_Menu.rice;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;


public class Ordershistory extends javax.swing.JFrame {
    
// ** 1. ตัวแปร Global (Private Static Data) **
private static int nextOrderId = 1; 
private static final List<OrderEntry> orderHistory = new ArrayList<>();
    
//** 2. Class ย่อยสำหรับเก็บข้อมูล Order (Public Static Data Model) **
//    (แทน Order.java เพื่อให้ MyOrders เข้าถึงประเภทข้อมูลได้)
// =================================================================================
public static class OrderEntry {
public final String orderId;
public final LocalDateTime dateTime;
// ต้องกำหนด CartManager.CartItem ให้เข้าถึงได้
public final List<CartManager.CartItem> items; 
public final int totalPrice;
public String status;

public OrderEntry(String orderId, List<CartManager.CartItem> items, int totalPrice, String status) {
    this.orderId = orderId;
    this.dateTime = LocalDateTime.now();
    this.items = List.copyOf(items); // คัดลอกรายการสินค้า
    this.totalPrice = totalPrice;
    this.status = status;
}
   
    
public String getOrderId() { return orderId; }

public LocalDateTime getDateTime() {
    return dateTime;
}


public OrderItem[] getItems() {
    // TODO Auto-generated method stub
    throw new UnsupportedOperationException("Unimplemented method 'getItems'");
}
    }
    

// ** 3. เมธอดจัดการ Order (Public Static Manager Methods) **
// =================================================================================
    public static OrderEntry createNewOrder(List<CartManager.CartItem> items, int totalPrice) {
        String newId = String.format("#%04d", nextOrderId++);
        OrderEntry newOrder = new OrderEntry(newId, items, totalPrice, "ยังไม่ได้ชำระ");
        orderHistory.add(newOrder);
        return newOrder;
    }

    // เมธอดค้นหา (จำเป็นสำหรับการดูรายละเอียดและอัปเดต)
    public static OrderEntry findOrderById(String orderId) {
         return orderHistory.stream()
               .filter(o -> o.orderId.equals(orderId))
               .findFirst()
               .orElse(null);
    }
    
    // เมธอดอัปเดตสถานะ (เผื่อ Bill.java ในอนาคต)
    public static void updateOrderStatus(String orderId, String newStatus) {
        OrderEntry order = findOrderById(orderId);
        if (order != null) {
            order.status = newStatus;
        }
    }
       
    
    
    // ** 4. Logic ส่วน GUI (History View) **
    // ======================================================
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Ordershistory.class.getName());

    public Ordershistory() {
        initComponents();
        tableorder.setRowHeight(40);
        tableorder.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tableorder.setRowSelectionAllowed(true); 
        tableorder.setColumnSelectionAllowed(false);
        loadHistoryData(); 

        // ปรับฟอนต์ Tahoma ขนาด 14
        tableorder.setFont(new java.awt.Font("Tahoma", java.awt.Font.PLAIN, 14));
        tableorder.getTableHeader().setFont(new java.awt.Font("Tahoma", java.awt.Font.BOLD, 16));

        // จัดกลางทุก column
        javax.swing.table.DefaultTableCellRenderer centerRenderer = new javax.swing.table.DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(javax.swing.JLabel.CENTER);
        for (int i = 0; i < tableorder.getColumnCount(); i++) {
            tableorder.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
    }

    // เมธอดโหลดข้อมูลประวัติเข้าตาราง
    private void loadHistoryData() {
        DefaultTableModel model = (DefaultTableModel) tableorder.getModel();
        model.setRowCount(0);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

        // ดึงข้อมูลจาก private static list
        for (OrderEntry order : orderHistory) {
            
            String itemSummary = String.format("%d รายการ", order.items.size());

            model.addRow(new Object[]{
                order.orderId,                                          // 1. Order ID
                order.dateTime.format(formatter),                       // 2. Date/Time
                itemSummary,                                            // 3. Items (สรุป)
                order.totalPrice + " บาท",                              // 4. Total Price
                order.status                                            // 5. Status
            });
        }
    }
    // แก้ไข Logic ปุ่ม Details

    
    
    
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        myprofile = new javax.swing.JLabel();
        ORDERHISTORY = new javax.swing.JScrollPane();
        tableorder = new javax.swing.JTable();
        back = new javax.swing.JButton();
        details = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1280, 720));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(206, 215, 209));
        jPanel1.setPreferredSize(new java.awt.Dimension(1280, 720));
        jPanel1.setLayout(null);

        myprofile.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        myprofile.setText("Order History");
        jPanel1.add(myprofile);
        myprofile.setBounds(475, 50, 340, 58);

        tableorder.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Order ID", "Date/Time", "Items", "Total Price", "Status"
            }
        ));
        tableorder.getTableHeader().setReorderingAllowed(false);
        ORDERHISTORY.setViewportView(tableorder);
        if (tableorder.getColumnModel().getColumnCount() > 0) {
            tableorder.getColumnModel().getColumn(0).setResizable(false);
            tableorder.getColumnModel().getColumn(1).setResizable(false);
            tableorder.getColumnModel().getColumn(2).setResizable(false);
            tableorder.getColumnModel().getColumn(3).setResizable(false);
            tableorder.getColumnModel().getColumn(4).setResizable(false);
        }

        jPanel1.add(ORDERHISTORY);
        ORDERHISTORY.setBounds(175, 130, 930, 520);

        back.setBackground(new java.awt.Color(204, 204, 204));
        back.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/Back (4).png"))); // NOI18N
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        jPanel1.add(back);
        back.setBounds(50, 30, 18, 30);

        details.setText("Details");
        details.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                detailsActionPerformed(evt);
            }
        });
        jPanel1.add(details);
        details.setBounds(1140, 160, 75, 23);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        rice ricePage = new rice();
        ricePage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backActionPerformed

private void detailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_detailsActionPerformed
    int selectedRow = tableorder.getSelectedRow();
    
    if (selectedRow >= 0 && selectedRow < orderHistory.size()) {
        OrderEntry order = orderHistory.get(selectedRow);
        
        if (order != null && order.items != null && !order.items.isEmpty()) {
            StringBuilder itemsList = new StringBuilder("รายการที่สั่ง:\n");
            
            // **<<< โค้ดที่แก้ไข: ลูป for ต้องจบก่อนสร้าง JTextArea >>>**
            for (CartManager.CartItem item : order.items) {
                // สร้าง String รายการสินค้าในลูป
                itemsList.append("- ").append(item.getDetails());
            }
            // **<<< วงเล็บปิดลูป for อยู่ตรงนี้ >>>**

            // 1. สร้าง JTextArea พร้อม Font Tahoma
            javax.swing.JTextArea textArea = new javax.swing.JTextArea(itemsList.toString());
            
            // ตั้งค่า Font Tahoma ขนาด 14 
            textArea.setFont(new java.awt.Font("Tahoma", java.awt.Font.PLAIN, 14));
            textArea.setEditable(false);
            
            // 2. แสดง JTextArea แทน String
            JOptionPane.showMessageDialog(this, textArea, "Order Details", JOptionPane.INFORMATION_MESSAGE);
            
        } else {
            JOptionPane.showMessageDialog(this, "ไม่มีรายการสินค้าในออเดอร์นี้", "Order Details", JOptionPane.INFORMATION_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(this, "กรุณาเลือกออเดอร์ที่ต้องการดูรายละเอียด", "Order Details", JOptionPane.WARNING_MESSAGE);
    }
}

    
  

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane ORDERHISTORY;
    private javax.swing.JButton back;
    private javax.swing.JButton details;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel myprofile;
    private javax.swing.JTable tableorder;
    // End of variables declaration//GEN-END:variables

    public class OrderItem {

        public String getDetails() {
            // TODO Auto-generated method stub
            throw new UnsupportedOperationException("Unimplemented method 'getDetails'");
        }

        public int getPrice() {
            // TODO Auto-generated method stub
            throw new UnsupportedOperationException("Unimplemented method 'getPrice'");
        }
    }
}
