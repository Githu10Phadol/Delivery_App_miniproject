package UI_3_Pay;
import UI_2_Menu.rice;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class MyOrders extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(MyOrders.class.getName());

    public MyOrders() {
        initComponents();
        loadCartData();
    }
     
    
    private void loadCartData() {
    CartManager cart = CartManager.getInstance();
    DefaultTableModel model = (DefaultTableModel) tablemenu.getModel();
    model.setRowCount(0);
    
    for (CartManager.CartItem item : cart.getItems()) {
        model.addRow(new Object[]{
            item.getDetails(),           // คอลัมน์ 1: ชื่อเมนู
            item.getQuantity(),          // คอลัมน์ 2: จำนวน ⭐
            item.getPrice() + " บาท"     // คอลัมน์ 3: ราคารวม
        });
    }
    
    updateTotal();
    }
    private void updateTotal() {
        int totalPrice = CartManager.getInstance().getTotalPrice();
        total.setText("รวม  " + totalPrice + "  บาท");
    }

    
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        myorders = new javax.swing.JLabel();
        total = new javax.swing.JLabel();
        next = new javax.swing.JButton();
        back = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablemenu = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1280, 720));
        setResizable(false);
        setSize(new java.awt.Dimension(1280, 720));

        jPanel1.setBackground(new java.awt.Color(206, 215, 209));
        jPanel1.setPreferredSize(new java.awt.Dimension(1280, 720));
        jPanel1.setLayout(null);

        myorders.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        myorders.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        myorders.setText("My Orders");
        myorders.setMaximumSize(new java.awt.Dimension(232, 80));
        myorders.setPreferredSize(new java.awt.Dimension(232, 60));
        jPanel1.add(myorders);
        myorders.setBounds(500, 50, 250, 50);

        total.setBackground(new java.awt.Color(0, 0, 0));
        total.setFont(new java.awt.Font("Tahoma", 1, 30)); // NOI18N
        total.setText("รวม      บาท");
        jPanel1.add(total);
        total.setBounds(970, 500, 180, 40);

        next.setBackground(new java.awt.Color(217, 217, 217));
        next.setFont(new java.awt.Font("Tahoma", 0, 32)); // NOI18N
        next.setText("ดำเนินการต่อ");
        next.setToolTipText("");
        next.setBorder(null);
        next.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextActionPerformed(evt);
            }
        });
        jPanel1.add(next);
        next.setBounds(400, 600, 473, 72);

        back.setBackground(new java.awt.Color(204, 204, 204));
        back.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/Back (4).png"))); // NOI18N
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        jPanel1.add(back);
        back.setBounds(50, 30, 18, 30);

        tablemenu.setModel(new javax.swing.table.DefaultTableModel(
        new Object [][] {
        {null, null, null},
        {null, null, null},
        {null, null, null},
        {null, null, null},
        {null, null, null},
        {null, null, null},
        {null, null, null},
        {null, null, null},
        {null, null, null},
        {null, null, null}
        },
        new String [] {
        "MENU", "จำนวน", "PRICE"  // เพิ่มคอลัมน์กลาง
        }
        ) {
        boolean[] canEdit = new boolean [] {
        false, false, false  //ห้ามแก้ไขทั้ง 3 คอลัมน์
        };

        public boolean isCellEditable(int rowIndex, int columnIndex) {
        return canEdit [columnIndex];
        }
        });
        tablemenu.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(tablemenu);
        if (tablemenu.getColumnModel().getColumnCount() > 0) {
            tablemenu.getColumnModel().getColumn(0).setResizable(false);
            tablemenu.getColumnModel().getColumn(1).setResizable(false);
        }

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(290, 140, 640, 402);

        jButton1.setBackground(new java.awt.Color(206, 215, 209));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/delete.png"))); // NOI18N
        jButton1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(1030, 140, 46, 46);

        jButton2.setBackground(new java.awt.Color(206, 215, 209));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/add.png"))); // NOI18N
        jButton2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2);
        jButton2.setBounds(960, 140, 46, 46);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

     private void nextActionPerformed(java.awt.event.ActionEvent evt) {
        if (CartManager.getInstance().getItemCount() == 0) {
            JOptionPane.showMessageDialog(this, "กรุณาเพิ่มรายการอาหารก่อน!");
            return;
        }
        
    // 1. **สร้าง Order ใหม่และบันทึก:**
    //เรียกใช้ static method จาก Ordershistory.java
    Ordershistory.OrderEntry newOrder = Ordershistory.createNewOrder(CartManager.getInstance().getItems(),CartManager.getInstance().getTotalPrice() );
    
    
    // 2. ล้างตะกร้าสินค้าหลังจากสร้าง Order เสร็จ
        CartManager.getInstance().clearCart();
        
        
        Bill billpage = new Bill();
        billpage.setVisible(true);
        this.dispose();
   
    }

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        rice ricePage = new rice();
        ricePage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
    int selectedRow = tablemenu.getSelectedRow();
    
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "กรุณาเลือกเมนูที่ต้องการลบ!");
        return;
    }
    
    CartManager cart = CartManager.getInstance();
    CartManager.CartItem item = cart.getItems().get(selectedRow);
    
    // ลดจำนวน
    item.decreaseQuantity();
    
    // ถ้าจำนวนเป็น 0 ให้ลบออก
    if (item.getQuantity() == 0) {
        cart.removeItem(selectedRow);
    }
    
    // รีเฟรชตาราง
    loadCartData();
}

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
    int selectedRow = tablemenu.getSelectedRow();
    
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "กรุณาเลือกเมนูที่ต้องการเพิ่ม!");
        return;
    }
    
    CartManager cart = CartManager.getInstance();
    CartManager.CartItem item = cart.getItems().get(selectedRow);
    
    //เพิ่มจำนวน
    item.increaseQuantity();
    
    //รีเฟรชตาราง
    loadCartData();
}


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel myorders;
    private javax.swing.JButton next;
    private javax.swing.JTable tablemenu;
    private javax.swing.JLabel total;
    // End of variables declaration//GEN-END:variables
}
