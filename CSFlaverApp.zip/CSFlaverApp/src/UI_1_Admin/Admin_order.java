package UI_1_Admin;

import UI_1_User.login;
import UI_3_Pay.Ordershistory; 
import UI_3_Pay.CartManager;
import javax.swing.table.DefaultTableModel; 
import javax.swing.JOptionPane;

public class Admin_order extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Admin_order.class.getName());

    public Admin_order() {
        initComponents();
        loadAdminOrderData();     
    }
    
    private void loadAdminOrderData() {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0); 
    
        java.util.List<Ordershistory.OrderEntry> history = Ordershistory.getOrderHistory();    
    java.time.format.DateTimeFormatter formatter = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

        for (Ordershistory.OrderEntry order : history) {
            int totalItems = 0;
            for (CartManager.CartItem item : order.items) {
            totalItems += item.getQuantity();
        }

            String itemSummary = String.format("%d Menus (%d Items)", 
            order.items.size(),  
            totalItems           
        );

            model.addRow(new Object[]{
                order.orderId,
                order.dateTime.format(formatter),
                itemSummary, 
                order.totalPrice + " Baht",
                order.status
            });
            }
        }       
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        btorder = new javax.swing.JButton();
        btmenu = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        logout = new javax.swing.JButton();
        processBtn = new javax.swing.JButton();
        refreshBtn = new javax.swing.JButton();
        detailBtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setPreferredSize(new java.awt.Dimension(1280, 720));
        jPanel1.setLayout(null);

        jPanel15.setBackground(new java.awt.Color(204, 204, 204));
        jPanel15.setPreferredSize(new java.awt.Dimension(180, 720));

        btorder.setBackground(new java.awt.Color(217, 217, 217));
        btorder.setText("ORDER");
        btorder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btorderjButton1ActionPerformed(evt);
            }
        });

        btmenu.setText("MENU");
        btmenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmenujButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(btmenu, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btorder, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGap(190, 190, 190)
                .addComponent(btmenu, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(70, 70, 70)
                .addComponent(btorder, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel1.add(jPanel15);
        jPanel15.setBounds(0, 0, 240, 720);

    jTable1.setFont(new java.awt.Font("Tahoma", 0, 18));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ORDER ID", "DATE/TIME", "MENU", "PRICE", "STATUS"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.setRowHeight(40);
        jTable1.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
            jTable1.getColumnModel().getColumn(3).setResizable(false);
            jTable1.getColumnModel().getColumn(4).setResizable(false);
        }

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(260, 80, 790, 560);

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));
        jPanel3.setPreferredSize(new java.awt.Dimension(85, 720));
        jPanel3.setLayout(null);

    logout.setBackground(new java.awt.Color(204, 204, 204));
    logout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/logout 1.png")));
        logout.setBorder(null);
        logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutActionPerformed(evt);
            }
        });
        jPanel3.add(logout);
        logout.setBounds(17, 20, 40, 40);

        jPanel1.add(jPanel3);
        jPanel3.setBounds(1195, 0, 85, 720);

    processBtn.setFont(new java.awt.Font("Tahoma", 0, 14));
        processBtn.setText("Process");
        processBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                processBtnActionPerformed(evt);
            }
        });
        jPanel1.add(processBtn);
        processBtn.setBounds(1070, 300, 100, 30);

    refreshBtn.setFont(new java.awt.Font("Tahoma", 0, 14));
        refreshBtn.setText("Refresh");
        refreshBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshBtnActionPerformed(evt);
            }
        });
        jPanel1.add(refreshBtn);
        refreshBtn.setBounds(1070, 180, 100, 30);

    detailBtn.setFont(new java.awt.Font("Tahoma", 0, 14));
        detailBtn.setText("Detail");
        detailBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                detailBtnActionPerformed(evt);
            }
        });
        jPanel1.add(detailBtn);
        detailBtn.setBounds(1070, 420, 100, 30);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }

    private void btorderjButton1ActionPerformed(java.awt.event.ActionEvent evt) {
    }

    private void btmenujButton2ActionPerformed(java.awt.event.ActionEvent evt) {
        Admin AdminPage = new Admin();
        AdminPage.setVisible(true);
        this.dispose();
    }

    private void logoutActionPerformed(java.awt.event.ActionEvent evt) {
        login loginPage = new login();
        loginPage.setVisible(true);
        this.dispose();
    }

    private void refreshBtnActionPerformed(java.awt.event.ActionEvent evt) {
        loadAdminOrderData(); 
    }

    private void processBtnActionPerformed(java.awt.event.ActionEvent evt) {
        int selectedRow = jTable1.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an order to process.");
            return;
        }

        String selectedOrderId = (String) jTable1.getValueAt(selectedRow, 0); 
        
        String newStatus = (String) JOptionPane.showInputDialog(this, 
                "Select new status for Order " + selectedOrderId + ":", 
                "Update Status",
                JOptionPane.QUESTION_MESSAGE,
                null,
                new Object[]{"Preparing", "Completed", "Cancelled"},
                "Preparing");
        
        if (newStatus != null && !newStatus.trim().isEmpty()) {

            Ordershistory.updateOrderStatus(selectedOrderId, newStatus);
            
            loadAdminOrderData();
            JOptionPane.showMessageDialog(this, "Order " + selectedOrderId + " status updated to: " + newStatus);
        }
    }
    private void detailBtnActionPerformed(java.awt.event.ActionEvent evt) {
    int selectedRow = jTable1.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select an order to view details.");
        return;
    }
        
    String selectedOrderId = (String) jTable1.getValueAt(selectedRow, 0); 
    Ordershistory.OrderEntry selectedOrder = Ordershistory.findOrderById(selectedOrderId);
    
    if (selectedOrder != null && selectedOrder.items != null && !selectedOrder.items.isEmpty()) {
        
        StringBuilder itemsList = new StringBuilder();
        itemsList.append("═══════════════════════════════════\n");
        itemsList.append(String.format("Order ID: %s\n", selectedOrder.orderId));
        itemsList.append(String.format("Date: %s\n", 
            selectedOrder.dateTime.format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))));
        itemsList.append(String.format("Status: %s\n", selectedOrder.status));
        itemsList.append("═══════════════════════════════════\n\n");
        itemsList.append("Items:\n");
        
        int itemNumber = 1;
        int totalQuantity = 0;
        
        for (CartManager.CartItem item : selectedOrder.items) {
            itemsList.append(String.format("%d. %s\n", itemNumber++, item.getMenuName()));
            
            StringBuilder options = new StringBuilder("   ");
            if (item.getSize() != null) options.append(item.getSize()).append(", ");
            if (item.getMeat() != null) options.append(item.getMeat()).append(", ");
            if (item.getNoodle() != null) options.append(item.getNoodle()).append(", ");
            if (item.getSweetness() != null) options.append(item.getSweetness());
            
            if (options.length() > 3) {
                itemsList.append(options.toString().replaceAll(", ฿", "")).append("\n");
            }
            
            itemsList.append(String.format("   จำนวน: %d x %d Baht = %d Baht\n\n", 
                item.getQuantity(), 
                item.getBasePrice(), 
                item.getPrice()
            ));
            totalQuantity += item.getQuantity();
        }
        
        itemsList.append("───────────────────────────────────\n");
        itemsList.append(String.format("Total Items: %d\n", totalQuantity));
        itemsList.append(String.format("Total Price: %d Baht\n", selectedOrder.totalPrice));
        itemsList.append("═══════════════════════════════════");

        javax.swing.JTextArea textArea = new javax.swing.JTextArea(itemsList.toString());
        textArea.setFont(new java.awt.Font("Tahoma", java.awt.Font.PLAIN, 14));
        textArea.setEditable(false);
        
        javax.swing.JScrollPane scrollPane = new javax.swing.JScrollPane(textArea);
        scrollPane.setPreferredSize(new java.awt.Dimension(500, 400));
        
        JOptionPane.showMessageDialog(this, scrollPane, 
                                      "Order Details - " + selectedOrderId, 
                                      JOptionPane.INFORMATION_MESSAGE);
        
    } else {
        JOptionPane.showMessageDialog(this, "Order details not found or order is empty.", 
                                      "Error", JOptionPane.ERROR_MESSAGE);
    }
}
    
    private javax.swing.JButton btmenu;
    private javax.swing.JButton btorder;
    private javax.swing.JButton detailBtn;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton logout;
    private javax.swing.JButton processBtn;
    private javax.swing.JButton refreshBtn;
}