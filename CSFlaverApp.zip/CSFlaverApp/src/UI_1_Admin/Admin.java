﻿package UI_1_Admin;

import UI_1_User.login;
import UI_3_Pay.MenuManager; 
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane; 

public class Admin extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Admin.class.getName());

    public Admin() {
        initComponents();
        loadMenuTable();       
    }
    private void loadMenuTable() {
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0); 
        
        if (MenuManager.getInstance() != null) {
            for (MenuManager.MenuData menu : MenuManager.getInstance().getAllMenu().values()) {           
                 String statusText = menu.isOutOfStock ? " Out of Stock" : " Available";
                 model.addRow(new Object[]{menu.name, menu.price + " Baht", statusText});

            }
        }
    }
    
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        BtnORDER = new javax.swing.JButton();
        BtnMENU = new javax.swing.JButton();
        BtnAvailable = new javax.swing.JButton();
        BtnOutStock = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        logout = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        setSize(new java.awt.Dimension(1280, 720));

        jPanel1.setPreferredSize(new java.awt.Dimension(1280, 720));
        jPanel1.setLayout(null);

        jTable1.setFont(new java.awt.Font("Tahoma", 0, 14));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "MENU", "PRICE", "STATUS"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.setRowHeight(40);
        jTable1.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
        }

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(310, 60, 600, 600);

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));
        jPanel2.setPreferredSize(new java.awt.Dimension(180, 720));
        jPanel2.setLayout(null);

    BtnORDER.setFont(new java.awt.Font("Tahoma", 0, 14));
        BtnORDER.setText("ORDER");
        BtnORDER.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnORDERActionPerformed(evt);
            }
        });
        jPanel2.add(BtnORDER);
        BtnORDER.setBounds(45, 299, 143, 39);

        BtnMENU.setBackground(new java.awt.Color(217, 217, 217));
    BtnMENU.setFont(new java.awt.Font("Tahoma", 0, 14));
        BtnMENU.setText("MENU");
        jPanel2.add(BtnMENU);
        BtnMENU.setBounds(46, 190, 143, 39);

        jPanel1.add(jPanel2);
        jPanel2.setBounds(0, 0, 240, 720);

    BtnAvailable.setFont(new java.awt.Font("Tahoma", 0, 20));
        BtnAvailable.setText("Mark available");
        BtnAvailable.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnAvailableActionPerformed(evt);
            }
        });
        jPanel1.add(BtnAvailable);
        BtnAvailable.setBounds(970, 180, 170, 32);

    BtnOutStock.setFont(new java.awt.Font("Tahoma", 0, 20));
        BtnOutStock.setText("Out of stock");
        BtnOutStock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnOutStockActionPerformed(evt);
            }
        });
        jPanel1.add(BtnOutStock);
        BtnOutStock.setBounds(970, 290, 170, 32);

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));
        jPanel3.setPreferredSize(new java.awt.Dimension(85, 720));
        jPanel3.setLayout(null);

    logout.setBackground(new java.awt.Color(204, 204, 204));
    logout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/logout 1.png")));
        logout.setBorder(null);
        logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutActionPerformed(evt);
            }
        });
        jPanel3.add(logout);
        logout.setBounds(17, 20, 40, 40);

        jPanel1.add(jPanel3);
        jPanel3.setBounds(1195, 0, 85, 720);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        pack();
        setLocationRelativeTo(null);
    }

    private void logoutActionPerformed(java.awt.event.ActionEvent evt) {
        login loginPage = new login();
        loginPage.setVisible(true);
        this.dispose();
    }

    private void BtnORDERActionPerformed(java.awt.event.ActionEvent evt) {
        Admin_order orderPage = new Admin_order();
        orderPage.setVisible(true);
        this.dispose();   
    }

    private void BtnAvailableActionPerformed(java.awt.event.ActionEvent evt) {
         int selectedRow = jTable1.getSelectedRow();
            if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a menu item to mark as Available.", "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String menuName = (String) jTable1.getValueAt(selectedRow, 0); 
        MenuManager.getInstance().updateStockStatus(menuName, false);
        loadMenuTable(); 
        JLabel msg = new JLabel(menuName + " is now  Available.");
        msg.setFont(new java.awt.Font("Tahoma", java.awt.Font.PLAIN, 14));
        JOptionPane.showMessageDialog(this, msg);
    }

    private void BtnOutStockActionPerformed(java.awt.event.ActionEvent evt) {
        int selectedRow = jTable1.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a menu item to mark as Out of Stock.", "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String menuName = (String) jTable1.getValueAt(selectedRow, 0);
        
        javax.swing.JLabel confirmMsg = new javax.swing.JLabel("Mark " + menuName + " as Out of Stock?");
        confirmMsg.setFont(new java.awt.Font("Tahoma", java.awt.Font.PLAIN, 14)); 

        int confirm = JOptionPane.showConfirmDialog(this,confirmMsg,"Confirm Status Change",JOptionPane.YES_NO_OPTION);
                          
        
        if (confirm == JOptionPane.YES_OPTION) {
            MenuManager.getInstance().updateStockStatus(menuName, true); 
            loadMenuTable(); 
            JLabel msg = new JLabel(menuName + " is now Out of Stock.");
            msg.setFont(new java.awt.Font("Tahoma", java.awt.Font.PLAIN, 14));
            JOptionPane.showMessageDialog(this, msg);
        }
    }

    private javax.swing.JButton BtnAvailable;
    private javax.swing.JButton BtnMENU;
    private javax.swing.JButton BtnORDER;
    private javax.swing.JButton BtnOutStock;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton logout;
}
