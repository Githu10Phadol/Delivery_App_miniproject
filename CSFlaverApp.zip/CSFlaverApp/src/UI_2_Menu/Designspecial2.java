package UI_2_Menu;

import javax.swing.ImageIcon;
import java.awt.Image;
import UI_3_Pay.MyOrders;
import UI_3_Pay.CartManager;
import UI_3_Pay.MenuManager;
public class Designspecial2 extends javax.swing.JFrame {
    private String menuName;
    private String specialnameMenu;

    public Designspecial2(String menuName, String specialnameMenu) {
        initComponents();
        this.menuName = menuName;
        this.specialnameMenu = specialnameMenu;
        showMenuImage();
        setTitle(specialnameMenu);
    }

    private void showMenuImage() {
        try {
            String imagePath = "src/noodles/" + menuName + ".png";
            ImageIcon icon = new ImageIcon(imagePath);
            Image img = icon.getImage().getScaledInstance(imagenoodles.getWidth(), imagenoodles.getHeight(), Image.SCALE_SMOOTH);
            imagenoodles.setIcon(new ImageIcon(img));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    private int getBasePriceFromCSV(String specialnameMenu) {
        String csvFile = "src/datacsv/Filemenu.csv";
        try (java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(new java.io.FileInputStream(csvFile), java.nio.charset.StandardCharsets.UTF_8))) {
            String line;
            br.readLine();
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2) {
                    if (parts[0].trim().equals(specialnameMenu.trim())) {
                        return Integer.parseInt(parts[1].trim());
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 55;
    }

    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        Design = new javax.swing.JLabel();
        select = new javax.swing.JLabel();
        normal = new javax.swing.JRadioButton();
        special = new javax.swing.JRadioButton();
        selectmeat = new javax.swing.JLabel();
        pig = new javax.swing.JRadioButton();
        chicken = new javax.swing.JRadioButton();
        addcart = new javax.swing.JButton();
        back = new javax.swing.JButton();
        imagenoodles = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(206, 215, 209));
        jPanel1.setPreferredSize(new java.awt.Dimension(1280, 720));
        jPanel1.setLayout(null);

        Design.setFont(new java.awt.Font("Tahoma", 1, 36));
        Design.setText("ปรับแต่ง");
        jPanel1.add(Design);
        Design.setBounds(550, 50, 140, 40);

        select.setFont(new java.awt.Font("Tahoma", 0, 24));
        select.setText("เลือกขนาด");
        jPanel1.add(select);
        select.setBounds(330, 120, 110, 29);

        normal.setBackground(new java.awt.Color(206, 215, 209));
        buttonGroup1.add(normal);
        normal.setFont(new java.awt.Font("Tahoma", 0, 20));
        normal.setText("ธรรมดา");
        normal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                normalActionPerformed(evt);
            }
        });
        jPanel1.add(normal);
        normal.setBounds(350, 170, 90, 30);

        special.setBackground(new java.awt.Color(206, 215, 209));
        buttonGroup1.add(special);
        special.setFont(new java.awt.Font("Tahoma", 0, 20));
        special.setText("พิเศษ");
        special.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                specialActionPerformed(evt);
            }
        });
        jPanel1.add(special);
        special.setBounds(500, 170, 90, 30);

        selectmeat.setFont(new java.awt.Font("Tahoma", 0, 24));
        selectmeat.setText("เนื้อ");
        jPanel1.add(selectmeat);
        selectmeat.setBounds(330, 250, 37, 29);
        pig.setBackground(new java.awt.Color(206, 215, 209));
        buttonGroup2.add(pig);
        pig.setFont(new java.awt.Font("Tahoma", 0, 20));
        pig.setText("หมู");
        pig.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pigActionPerformed(evt);
            }
        });
        jPanel1.add(pig);
        pig.setBounds(350, 300, 50, 30);
        chicken.setBackground(new java.awt.Color(206, 215, 209));
        buttonGroup2.add(chicken);
        chicken.setFont(new java.awt.Font("Tahoma", 0, 20));
        chicken.setText("ไก่");
        chicken.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chickenActionPerformed(evt);
            }
        });
        jPanel1.add(chicken);
        chicken.setBounds(500, 300, 60, 30);
        addcart.setBackground(new java.awt.Color(217, 217, 217));
        addcart.setFont(new java.awt.Font("Tahoma", 1, 25));
        addcart.setText("ใส่ตะกร้า");
        addcart.setBorder(null);
        addcart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addcartActionPerformed(evt);
            }
        });
        jPanel1.add(addcart);
        addcart.setBounds(500, 550, 220, 40);
        back.setBackground(new java.awt.Color(204, 204, 204));
        back.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/Back (4).png")));
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        jPanel1.add(back);
        back.setBounds(50, 30, 18, 30);
        jPanel1.add(imagenoodles);
        imagenoodles.setBounds(80, 130, 150, 150);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }                   

    private void chickenActionPerformed(java.awt.event.ActionEvent evt) {                                        
    }                                       

    private void pigActionPerformed(java.awt.event.ActionEvent evt) {                                    
    }                                   

    private void specialActionPerformed(java.awt.event.ActionEvent evt) {                                        
    }                                       

    private void normalActionPerformed(java.awt.event.ActionEvent evt) {                                       
    }                                      

    private void addcartActionPerformed(java.awt.event.ActionEvent evt) {
        if (!normal.isSelected() && !special.isSelected()) {
            javax.swing.JLabel msg = new javax.swing.JLabel("กรุณาเลือกขนาด!");
            msg.setFont(new java.awt.Font("Tahoma", java.awt.Font.PLAIN, 18));
            javax.swing.JOptionPane.showMessageDialog(this, msg, "แจ้งเตือน", javax.swing.JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if (!pig.isSelected() && !chicken.isSelected()) {
            javax.swing.JLabel msg = new javax.swing.JLabel("กรุณาเลือกเนื้อ!");
            msg.setFont(new java.awt.Font("Tahoma", java.awt.Font.PLAIN, 18));
            javax.swing.JOptionPane.showMessageDialog(this, msg, "แจ้งเตือน", javax.swing.JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        int basePrice = MenuManager.getInstance().getMenu(menuName).price;

        String size = normal.isSelected() ? "ธรรมดา" : "พิเศษ";
        String meat = pig.isSelected() ? "หมู" : "ไก่";

        int finalPrice = basePrice;
        if (size.equals("พิเศษ")) {
            finalPrice += 10;
        }

        CartManager.CartItem item = new CartManager.CartItem(
            specialnameMenu,
            menuName,
            "special",
            basePrice
        );
        item.setSize(size);
        item.setMeat(meat);
        item.setPrice(finalPrice);

        CartManager.getInstance().addItem(item);

        javax.swing.JLabel msg = new javax.swing.JLabel("เพิ่มลงตะกร้าแล้ว!");
        msg.setFont(new java.awt.Font("Tahoma", java.awt.Font.PLAIN, 18));
        javax.swing.JOptionPane.showMessageDialog(this, msg, "สำเร็จ", javax.swing.JOptionPane.INFORMATION_MESSAGE);

        MyOrders myordersPage = new MyOrders();
        myordersPage.setVisible(true);
        this.dispose();
    }

    private void backActionPerformed(java.awt.event.ActionEvent evt) {
        noodles noodlesPage = new noodles();
        noodlesPage.setVisible(true);
        this.dispose();
    }                                    
                
    private javax.swing.JLabel Design;
    private javax.swing.JButton addcart;
    private javax.swing.JButton back;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JRadioButton chicken;
    private javax.swing.JLabel imagenoodles;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton normal;
    private javax.swing.JRadioButton pig;
    private javax.swing.JLabel select;
    private javax.swing.JLabel selectmeat;
    private javax.swing.JRadioButton special;               
}
