package UI_3_Pay;
import UI_2_Menu.rice;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class MyOrders extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(MyOrders.class.getName());

    public MyOrders() {
        initComponents();
        loadCartData();
    }
     
    private void loadCartData() {
    CartManager cart = CartManager.getInstance();
    DefaultTableModel model = (DefaultTableModel) tablemenu.getModel();
    model.setRowCount(0);
    
    for (CartManager.CartItem item : cart.getItems()) {
        model.addRow(new Object[]{
            item.getDetails(),           // คอลัมน์ 1: ชื่อเมนู
            item.getQuantity(),          // คอลัมน์ 2: จำนวน 
            item.getPrice() + " บาท"     // คอลัมน์ 3: ราคารวม
        });
    }
    updateTotal();
    }
    private void updateTotal() {
        int totalPrice = CartManager.getInstance().getTotalPrice();
        total.setText("รวม  " + totalPrice + "  บาท");
    }
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        myorders = new javax.swing.JLabel();
        total = new javax.swing.JLabel();
        next = new javax.swing.JButton();
        back = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablemenu = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1280, 720));
        setResizable(false);
        setSize(new java.awt.Dimension(1280, 720));

        jPanel1.setBackground(new java.awt.Color(206, 215, 209));
        jPanel1.setPreferredSize(new java.awt.Dimension(1280, 720));
        jPanel1.setLayout(null);

        myorders.setFont(new java.awt.Font("Tahoma", 1, 48));
        myorders.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        myorders.setText("My Orders");
        myorders.setMaximumSize(new java.awt.Dimension(232, 80));
        myorders.setPreferredSize(new java.awt.Dimension(232, 60));
        jPanel1.add(myorders);
        myorders.setBounds(500, 50, 250, 50);

        total.setBackground(new java.awt.Color(0, 0, 0));
        total.setFont(new java.awt.Font("Tahoma", 0, 24));
        total.setText("รวม      บาท");
        jPanel1.add(total);
        total.setBounds(970, 500, 180, 40);

        next.setBackground(new java.awt.Color(217, 217, 217));
        next.setFont(new java.awt.Font("Tahoma", 0, 32));
        next.setText("ดำเนินการต่อ");
        next.setToolTipText("");
        next.setBorder(null);
        next.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextActionPerformed(evt);
            }
        });
        jPanel1.add(next);
        next.setBounds(400, 600, 473, 72);
        back.setBackground(new java.awt.Color(204, 204, 204));
        back.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/Back (4).png")));
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        jPanel1.add(back);
        back.setBounds(50, 30, 18, 30);

        tablemenu.setFont(new java.awt.Font("Tahoma", 0, 14));
        tablemenu.setModel(new javax.swing.table.DefaultTableModel(
        new Object [][] {
        {null, null, null},
        {null, null, null},
        {null, null, null},
        {null, null, null},
        {null, null, null},
        {null, null, null},
        {null, null, null},
        {null, null, null},
        {null, null, null},
        {null, null, null}
        },
        new String [] {
        "Menu", "Quantity", "Price"
        }
        ) {
        boolean[] canEdit = new boolean [] {
        false, false, false
        };
        public boolean isCellEditable(int rowIndex, int columnIndex) {
        return canEdit [columnIndex];
        }
        });
        tablemenu.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(tablemenu);
        if (tablemenu.getColumnModel().getColumnCount() > 0) {
            tablemenu.getColumnModel().getColumn(0).setResizable(false);
            tablemenu.getColumnModel().getColumn(1).setResizable(false);
        }

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(290, 140, 640, 400);
        jButton1.setBackground(new java.awt.Color(206, 215, 209));
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/delete.png")));
        jButton1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(1030, 140, 46, 46);

        jButton2.setBackground(new java.awt.Color(206, 215, 209));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/add.png")));
        jButton2.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2);
        jButton2.setBounds(960, 140, 46, 46);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }
    private void nextActionPerformed(java.awt.event.ActionEvent evt) {
    if (CartManager.getInstance().getItemCount() == 0) {
        javax.swing.JLabel msg = new javax.swing.JLabel("กรุณาเพิ่มรายการอาหารก่อน!");
        msg.setFont(new java.awt.Font("Tahoma", 0, 18));
        javax.swing.JOptionPane.showMessageDialog(this, msg, "แจ้งเตือน", javax.swing.JOptionPane.INFORMATION_MESSAGE);
        return;
    }
    
    //  1. สร้าง Order ใหม่ (ยังไม่ล้างตะกร้า)
    Ordershistory.OrderEntry newOrder = Ordershistory.createNewOrder(
        CartManager.getInstance().getItems(),
        CartManager.getInstance().getTotalPrice()
    );
    
    //  2. ส่ง Order ไปหน้า Bill
    Bill billpage = new Bill(newOrder); // ส่ง order เข้าไป
    billpage.setVisible(true);
    this.dispose();
    
    //  3. ล้างตะกร้า (ทำหลังจากส่งข้อมูลแล้ว)
    CartManager.getInstance().clearCart();
    }

    private void backActionPerformed(java.awt.event.ActionEvent evt) {
        rice ricePage = new rice();
        ricePage.setVisible(true);
        this.dispose();
    }

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
    int selectedRow = tablemenu.getSelectedRow();
    
    if (selectedRow == -1) {
        javax.swing.JLabel msg = new javax.swing.JLabel("กรุณาเลือกเมนูที่ต้องการลบ!");
        msg.setFont(new java.awt.Font("Tahoma", java.awt.Font.PLAIN, 18));
        javax.swing.JOptionPane.showMessageDialog(this, msg, "แจ้งเตือน", javax.swing.JOptionPane.INFORMATION_MESSAGE);
        return;
    }
    
    CartManager cart = CartManager.getInstance();
    CartManager.CartItem item = cart.getItems().get(selectedRow);
    
    // ลดจำนวน
    item.decreaseQuantity();
    
    // ถ้าจำนวนเป็น 0 ให้ลบออก
    if (item.getQuantity() == 0) {
        cart.removeItem(selectedRow);
    }
    
    // รีเฟรชตาราง
    loadCartData();
    
    //  เลือกแถวเดิมอีกครั้ง (ถ้ายังมีแถวนั้นอยู่)
    if (selectedRow < tablemenu.getRowCount()) {
        tablemenu.setRowSelectionInterval(selectedRow, selectedRow);
    } else if (tablemenu.getRowCount() > 0) {
        // ถ้าลบแถวสุดท้าย ให้เลือกแถวก่อนหน้า
        tablemenu.setRowSelectionInterval(selectedRow - 1, selectedRow - 1);
    }
}

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
    int selectedRow = tablemenu.getSelectedRow();
    
    if (selectedRow == -1) {
        javax.swing.JLabel msg = new javax.swing.JLabel("กรุณาเลือกเมนูที่ต้องการเพิ่ม!");
        msg.setFont(new java.awt.Font("Tahoma", java.awt.Font.PLAIN, 18));
        javax.swing.JOptionPane.showMessageDialog(this, msg, "แจ้งเตือน", javax.swing.JOptionPane.INFORMATION_MESSAGE);
        return;
    }
    
    CartManager cart = CartManager.getInstance();
    CartManager.CartItem item = cart.getItems().get(selectedRow);
    
    // เพิ่มจำนวน
    item.increaseQuantity();
    
    // รีเฟรชตาราง
    loadCartData();
    
    if (selectedRow < tablemenu.getRowCount()) {
        tablemenu.setRowSelectionInterval(selectedRow, selectedRow);
    }
}


    private javax.swing.JButton back;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel myorders;
    private javax.swing.JButton next;
    private javax.swing.JTable tablemenu;
    private javax.swing.JLabel total;
}
