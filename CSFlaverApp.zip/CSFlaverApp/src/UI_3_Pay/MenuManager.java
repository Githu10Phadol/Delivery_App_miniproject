package UI_3_Pay;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedWriter;
import java.util.HashMap;
import java.nio.charset.StandardCharsets; 
import java.nio.file.Files;
import java.nio.file.Paths;

public class MenuManager{
    private static MenuManager instance;
    private HashMap<String, MenuData> menuMap;
    
    public static class MenuData {
        public String name;
        public int price;
        public String custom;    
        public String options;   
        public String imagePath; 
        public boolean isOutOfStock;
        
        public MenuData(String name, int price, String custom, String options, String imagePath, boolean isOutOfStock) {
            this.name = name;
            this.price = price;
            this.custom = custom;
            this.options = options;
            this.imagePath = imagePath;
            this.isOutOfStock = isOutOfStock;
        }
    }
    private MenuManager() {
        menuMap = new HashMap<>();
        loadMenu();
    }
    
    public static MenuManager getInstance() {
        if (instance == null) {
            instance = new MenuManager();
        }
        return instance;
    }
    
    private void loadMenu() {
    menuMap.clear();

    try (BufferedReader br = Files.newBufferedReader(
             Paths.get("src/datacsv/Filemenu.csv"), StandardCharsets.UTF_8)) { 
        
        br.readLine(); 
        
        String line;
        while ((line = br.readLine()) != null) {
            String[] parts = splitCSV(line);
            
        
            if (parts.length >= 5) {
                String menuName = parts[0];
                int price = Integer.parseInt(parts[1]);
                String custom = parts[2]; 
                String options = parts[3]; 
                String imagePath = parts[4];
                boolean outOfStock = (parts.length >= 6) && parts[5].trim().equalsIgnoreCase("true"); 
                String key = getFileName(imagePath);
                menuMap.put(key, new MenuData(menuName, price, custom, options, imagePath, outOfStock));
            }
        }
    } catch (Exception e) { 
        System.out.println("Error loading menu: " + e.getMessage());
        e.printStackTrace();
    }
}

    private void saveMenu() {
  
    try (BufferedWriter bw = Files.newBufferedWriter(
             Paths.get("src/datacsv/Filemenu.csv"), StandardCharsets.UTF_8)) { 
        
        bw.write("namemenu,price,custom,options,picmenu,isOutOfStock\n"); 
        
        for (MenuData data : menuMap.values()) { 
            String line = String.format("\"%s\",%d,\"%s\",\"%s\",%s,%s\n", 
                                          data.name, 
                                          data.price, 
                                          data.custom, 
                                          data.options,
                                          data.imagePath,
                                          String.valueOf(data.isOutOfStock)); 
            bw.write(line);
        }
    } catch (IOException e) {
        System.err.println("Error saving menu: " + e.getMessage());
        e.printStackTrace();
    }
}
    public void updateStockStatus(String menuName, boolean isOutOfStock) {
        String keyToUpdate = null;
        
        for (java.util.Map.Entry<String, MenuData> entry : menuMap.entrySet()) {
            if (entry.getValue().name.equals(menuName)) {
                keyToUpdate = entry.getKey();
                break;
            }
        }
        
        if (keyToUpdate != null) {
            menuMap.get(keyToUpdate).isOutOfStock = isOutOfStock; 
            saveMenu(); 
        } else {
             System.err.println("Error: Menu item '" + menuName + "' not found.");
        }
    }

    public boolean checkStockStatus(String menuName) {
        for (MenuData data : menuMap.values()) {
            if (data.name.equals(menuName)) {
                return data.isOutOfStock; 
            }
        }
        return false; 
    }

    public HashMap<String, MenuData> getAllMenu() {
        return menuMap;
    }

    private String[] splitCSV(String line) {
        String[] result = new String[6];
        int index = 0;
        boolean inQuotes = false;
        StringBuilder current = new StringBuilder();
        
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '"') {
                inQuotes = !inQuotes;
            } else if (c == ',' && !inQuotes) {
                if(index < 6){
                result[index++] = current.toString().trim();
                current = new StringBuilder();
            } else {
                current.append(c);
            }
        } else {
                current.append(c);
            }
        }
        if (index < 6) { 
            result[index] = current.toString().trim();
        }
        return result;
    }
    
    private String getFileName(String path) {
        String[] parts = path.split("/");
        String file = parts[parts.length - 1];
        return file.replace(".png", "");
    }

    public MenuData getMenu(String key) {
        return menuMap.get(key);
    }
}