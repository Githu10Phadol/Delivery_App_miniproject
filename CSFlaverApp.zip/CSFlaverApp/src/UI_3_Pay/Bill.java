package UI_3_Pay;
import UI_2_Menu.rice;
import javax.swing.DefaultListModel;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
public class Bill extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Bill.class.getName());
    private Ordershistory.OrderEntry currentOrder; //  เก็บ Order ปัจจุบัน
    public Bill() {
        initComponents();
        loadBillData();
    }
    public Bill(Ordershistory.OrderEntry order) {
        initComponents();
        this.currentOrder = order;
        loadBillDataFromOrder(); // โหลดจาก Order
    }
    private void loadBillData() {
        CartManager cart = CartManager.getInstance();
        DefaultListModel<String> listModel = new DefaultListModel<>();
         
        for (CartManager.CartItem item : cart.getItems()) {
            listModel.addElement(item.getDetails() + " - " + item.getPrice() + " บาท");
        }
        
        list.setModel(listModel);
        
        int totalPrice = cart.getTotalPrice();
        total.setText("รวม  " + totalPrice + "  บาท");
    }
    private void loadBillDataFromOrder() {
    DefaultListModel<String> listModel = new DefaultListModel<>();
    
    for (CartManager.CartItem item : currentOrder.items) {
        //  ข้าวผัดกะเพรา (หมู, พิเศษ) x2 = 100 บาท
        String line = String.format("%s x%d = %d บาท", 
            item.getDetails(), 
            item.getQuantity(), 
            item.getPrice()
        );
        listModel.addElement(line);
    }
    
    list.setModel(listModel);
    total.setText("รวม  " + currentOrder.totalPrice + "  บาท");
}
    private void saveOrderToCSV() {
    try {
        FileWriter fw = new FileWriter("src/datacsv/Orders.csv", true);
        BufferedWriter bw = new BufferedWriter(fw);
        
        CartManager cart = CartManager.getInstance();
        
        java.util.HashMap<String, Integer> menuCount = new java.util.HashMap<>();
        java.util.HashMap<String, Integer> menuPrice = new java.util.HashMap<>();
        
        for (CartManager.CartItem item : cart.getItems()) {
            String key = item.getDetails();
            menuCount.put(key, menuCount.getOrDefault(key, 0) + 1);
            menuPrice.put(key, item.getPrice());
        }
        
        for (String menu : menuCount.keySet()) {
            int quantity = menuCount.get(menu);
            int price = menuPrice.get(menu);
            int total = price * quantity;
            
            bw.write(menu + "," + price + "," + quantity);
            bw.newLine();
        }
        bw.newLine();
        bw.flush();
        bw.close();
        fw.close();
        
    } catch (Exception e) {
        System.out.println("Error saving order: " + e);
    }
}
        private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        bill = new javax.swing.JLabel();
        total = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        list = new javax.swing.JList<>();
        payment = new javax.swing.JButton();
        back = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1280, 720));
        setResizable(false);
        setSize(new java.awt.Dimension(1280, 720));

        jPanel1.setBackground(new java.awt.Color(206, 215, 209));
        jPanel1.setMaximumSize(new java.awt.Dimension(1280, 720));
        jPanel1.setMinimumSize(new java.awt.Dimension(1280, 720));
        jPanel1.setPreferredSize(new java.awt.Dimension(1280, 720));
        jPanel1.setLayout(null);

    bill.setFont(new java.awt.Font("Tahoma", 0, 60));
        bill.setText("Bill");
        jPanel1.add(bill);
        bill.setBounds(560, 50, 77, 73);

    total.setBackground(new java.awt.Color(0, 0, 0));
    total.setFont(new java.awt.Font("Tahoma", 0, 24));
        total.setText("รวม      บาท");
        jPanel1.add(total);
        total.setBounds(970, 500, 500, 40);

        list.setBorder(null);
        list.setFont(new java.awt.Font("Tahoma", 0, 28)); 
        list.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "ก๋วยเตี๋ยว บะหมี่ หมู พิเศษ", "ข้าวไข่เจียว หมู พิเศษ", "ข้าวเหนียวมะม่วง หวานปกติ", "น้ำโคล่า แก้วใหญ่" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        list.setToolTipText("");
        jScrollPane1.setViewportView(list);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(290, 140, 640, 400);

        payment.setBackground(new java.awt.Color(217, 217, 217));
        payment.setFont(new java.awt.Font("Tahoma", 0, 32));
        payment.setText("ชำระเงิน");
        payment.setToolTipText("");
        payment.setBorder(null);
        payment.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paymentActionPerformed(evt);
            }
        });
        jPanel1.add(payment);
        payment.setBounds(400, 600, 473, 72);
    back.setBackground(new java.awt.Color(204, 204, 204));
    back.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/Back (4).png")));
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        jPanel1.add(back);
        back.setBounds(50, 30, 18, 30);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }

    private void paymentActionPerformed(java.awt.event.ActionEvent evt) {
    saveOrderToCSV();//  บันทึก Order ลง CSV
    
    //  อัพเดทสถานะ Order
    if (currentOrder != null) {
        Ordershistory.updateOrderStatus(currentOrder.orderId, "ชำระเงินแล้ว");
    }
    
    Final finalPage = new Final();
    finalPage.setVisible(true);
    this.dispose();
    }

    private void backActionPerformed(java.awt.event.ActionEvent evt) {                                     
        rice ricePage = new rice();
        ricePage.setVisible(true);
        this.dispose();
    }

    private javax.swing.JButton back;
    private javax.swing.JLabel bill;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList<String> list;
    private javax.swing.JButton payment;
    private javax.swing.JLabel total;
}
