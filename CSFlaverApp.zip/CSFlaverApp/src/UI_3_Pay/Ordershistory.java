package UI_3_Pay;
import UI_2_Menu.rice;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;


public class Ordershistory extends javax.swing.JFrame {

private static int nextOrderId = 1; 
private static final List<OrderEntry> orderHistory = new ArrayList<>();

public static class OrderEntry {
public final String orderId;
public final LocalDateTime dateTime;
public final List<CartManager.CartItem> items; 
public final int totalPrice;
public String status;

public OrderEntry(String orderId, List<CartManager.CartItem> items, int totalPrice, String status) {
    this.orderId = orderId;
    this.dateTime = LocalDateTime.now();
    this.items = List.copyOf(items);
    this.totalPrice = totalPrice;
    this.status = status;
}
   
    
public String getOrderId() { return orderId; }

public LocalDateTime getDateTime() {
    return dateTime;
}


public OrderItem[] getItems() {
    throw new UnsupportedOperationException("Unimplemented method 'getItems'");
}
    }
    
    public static OrderEntry createNewOrder(List<CartManager.CartItem> items, int totalPrice) {
        String newId = String.format("#%04d", nextOrderId++);
        OrderEntry newOrder = new OrderEntry(newId, items, totalPrice, "ยังไม่ได้ชำระ");
        orderHistory.add(newOrder);
        return newOrder;
    }

    public static OrderEntry findOrderById(String orderId) {
         return orderHistory.stream()
               .filter(o -> o.orderId.equals(orderId))
               .findFirst()
               .orElse(null);
    }
    
    public static void updateOrderStatus(String orderId, String newStatus) {
            for (OrderEntry order : orderHistory) {
            if (order.orderId.equals(orderId)) {
                order.status = newStatus;
                return;
            }
        }
    }
       
    public static List<OrderEntry> getOrderHistory() {
        return new ArrayList<>(orderHistory); 
    }
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Ordershistory.class.getName());

    public Ordershistory() {
        initComponents();
        tableorder.setRowHeight(40);
        tableorder.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tableorder.setRowSelectionAllowed(true); 
        tableorder.setColumnSelectionAllowed(false);
        loadHistoryData(); 

        
        tableorder.setFont(new java.awt.Font("Tahoma", java.awt.Font.PLAIN, 14));
        tableorder.getTableHeader().setFont(new java.awt.Font("Tahoma", java.awt.Font.BOLD, 16));

        javax.swing.table.DefaultTableCellRenderer centerRenderer = new javax.swing.table.DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(javax.swing.JLabel.CENTER);
        for (int i = 0; i < tableorder.getColumnCount(); i++) {
            tableorder.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }
    }
    private void loadHistoryData() {
    DefaultTableModel model = (DefaultTableModel) tableorder.getModel();
    model.setRowCount(0);

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    for (OrderEntry order : orderHistory) {
        int totalItems = 0;
        for (CartManager.CartItem item : order.items) {
            totalItems += item.getQuantity();
        }
        String itemSummary = String.format("%d เมนู (%d รายการ)", 
            order.items.size(),
            totalItems
        );

        model.addRow(new Object[]{
            order.orderId,
            order.dateTime.format(formatter),
            itemSummary,
            order.totalPrice + " บาท",
            order.status
        });
    }
}

    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        myprofile = new javax.swing.JLabel();
        ORDERHISTORY = new javax.swing.JScrollPane();
        tableorder = new javax.swing.JTable();
        back = new javax.swing.JButton();
        details = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1280, 720));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(206, 215, 209));
        jPanel1.setPreferredSize(new java.awt.Dimension(1280, 720));
        jPanel1.setLayout(null);

        myprofile.setFont(new java.awt.Font("Tahoma", 1, 48));
        myprofile.setText("Order History");
        jPanel1.add(myprofile);
        myprofile.setBounds(475, 50, 340, 58);

        tableorder.setFont(new java.awt.Font("Tahoma", 0, 18));
        tableorder.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Order ID", "Date/Time", "Items", "Total Price", "Status"
            }
        ){
        boolean[] canEdit = new boolean [] {
        false, false, false, false, false
        };

        public boolean isCellEditable(int rowIndex, int columnIndex) {
        return canEdit [columnIndex];
        }
        });
        tableorder.getTableHeader().setReorderingAllowed(false);
        ORDERHISTORY.setViewportView(tableorder);
        if (tableorder.getColumnModel().getColumnCount() > 0) {
            tableorder.getColumnModel().getColumn(0).setResizable(false);
            tableorder.getColumnModel().getColumn(1).setResizable(false);
            tableorder.getColumnModel().getColumn(2).setResizable(false);
            tableorder.getColumnModel().getColumn(3).setResizable(false);
            tableorder.getColumnModel().getColumn(4).setResizable(false);
        }

        jPanel1.add(ORDERHISTORY);
        ORDERHISTORY.setBounds(175, 130, 930, 520);

        back.setBackground(new java.awt.Color(204, 204, 204));
        back.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/Back (4).png")));
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        jPanel1.add(back);
        back.setBounds(50, 30, 18, 30);

        details.setFont(new java.awt.Font("Tahoma", 0, 14));
        details.setText("Details");
        details.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                detailsActionPerformed(evt);
            }
        });
        jPanel1.add(details);
        details.setBounds(1140, 160, 75, 23);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }

    private void backActionPerformed(java.awt.event.ActionEvent evt) {
        rice ricePage = new rice();
        ricePage.setVisible(true);
        this.dispose();
    }
private void detailsActionPerformed(java.awt.event.ActionEvent evt) {
    int selectedRow = tableorder.getSelectedRow();
    
    if (selectedRow >= 0 && selectedRow < orderHistory.size()) {
        OrderEntry order = orderHistory.get(selectedRow);
        
        if (order != null && order.items != null && !order.items.isEmpty()) {
            StringBuilder itemsList = new StringBuilder();
            
            itemsList.append("═════════════════════════════════════════════\n");
            itemsList.append("                                        รายละเอียด Order: ").append(order.orderId).append("\n");
            itemsList.append("═════════════════════════════════════════════\n\n");
            
            int itemNumber = 1;
            int totalQuantity = 0;
            
            for (CartManager.CartItem item : order.items) {
                itemsList.append(itemNumber++).append(". ");
                itemsList.append(item.getMenuName());
                
                if (item.getSize() != null) {
                    itemsList.append(" (").append(item.getSize());
                    if (item.getMeat() != null) {
                        itemsList.append(", ").append(item.getMeat());
                    }
                    if (item.getNoodle() != null) {
                        itemsList.append(", ").append(item.getNoodle());
                    }
                    itemsList.append(")");
                }
                
                itemsList.append("\n");
                itemsList.append("   จำนวน: ").append(item.getQuantity()).append(" รายการ\n");
                itemsList.append("   ราคา: ").append(item.getBasePrice())
                        .append(" x ").append(item.getQuantity())
                        .append(" = ").append(item.getPrice()).append(" บาท\n\n");
                totalQuantity += item.getQuantity();
            }
            

            itemsList.append("─────────────────────────────────────────────\n");
            itemsList.append("รวมทั้งหมด: ").append(totalQuantity).append(" รายการ\n");
            itemsList.append("ราคารวม: ").append(order.totalPrice).append(" บาท\n");
            itemsList.append("═════════════════════════════════════════════");

            
            javax.swing.JTextArea textArea = new javax.swing.JTextArea(itemsList.toString());
            textArea.setFont(new java.awt.Font("Tahoma", java.awt.Font.PLAIN, 14));
            textArea.setEditable(false);
            textArea.setBackground(new java.awt.Color(245, 245, 245));
            
            javax.swing.JScrollPane scrollPane = new javax.swing.JScrollPane(textArea);
            scrollPane.setPreferredSize(new java.awt.Dimension(500, 400));
            
            JOptionPane.showMessageDialog(this, scrollPane, 
                "Order Details - " + order.orderId, 
                JOptionPane.INFORMATION_MESSAGE);
            
        } else {
            javax.swing.JLabel msg = new javax.swing.JLabel("ไม่มีรายการสินค้าในออเดอร์นี้");
            msg.setFont(new java.awt.Font("Tahoma", 0, 16));
            javax.swing.JOptionPane.showMessageDialog(this, msg, "แจ้งเตือน", javax.swing.JOptionPane.INFORMATION_MESSAGE);
        }
    } else {
         javax.swing.JLabel msg = new javax.swing.JLabel("กรุณาเลือกออเดอร์ที่ต้องการดูรายละเอียด");
            msg.setFont(new java.awt.Font("Tahoma", 0, 16));
            javax.swing.JOptionPane.showMessageDialog(this, msg, "แจ้งเตือน", javax.swing.JOptionPane.INFORMATION_MESSAGE);
    }
}
    private javax.swing.JScrollPane ORDERHISTORY;
    private javax.swing.JButton back;
    private javax.swing.JButton details;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel myprofile;
    private javax.swing.JTable tableorder;

    public class OrderItem {
        public String getDetails() {
            throw new UnsupportedOperationException("Unimplemented method 'getDetails'");
        }
        public int getPrice() {
            throw new UnsupportedOperationException("Unimplemented method 'getPrice'");
        }
    }
}
