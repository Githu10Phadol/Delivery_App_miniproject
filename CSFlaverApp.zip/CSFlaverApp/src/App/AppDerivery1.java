
package App;

import UI_1_User.login;
import UI_2_Menu.Designdessert;
import UI_2_Menu.Designdrinks;
import UI_2_Menu.Designnoodles;
import UI_2_Menu.Designrice;
import UI_2_Menu.drinks;
import UI_2_Menu.noodles;
import UI_2_Menu.rice;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;



public class AppDerivery1 {

 
    public static void main(String[] args) {
            
            login login = new login();
            login.setVisible(true);
                    
           // Designrice designricepage = new Designrice();
           // designricepage.setVisible(true);
            
           // Designnoodles designnoodlespage = new Designnoodles();
           // designnoodlespage.setVisible(true);
            
            //Designdrinks designdrinkpage = new Designdrinks();
            //designdrinkpage.setVisible(true);
            
           // Designdessert designdessertpage = new Designdessert();
           // designdessertpage.setVisible(true);
           
              //rice ricepage = new rice();
              //ricepage.setVisible(true);
              
             // drinks drinkpage = new drinks();
             // drinkpage.setVisible(true);
              
             // noodles noodlespage = new noodles();
             /// noodlespage.setVisible(true);
              
              //rice ricepage = new rice();
              //ricepage.setVisible(true);
            

           
}
}


