
package App;

import UI_1_User.login;




public class AppDerivery1 {

 
    public static void main(String[] args) {
            
            login login = new login();
            login.setVisible(true);
                    
                    
    }
}
