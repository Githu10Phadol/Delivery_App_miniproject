
package App;

import UI_1_Admin.Admin;
import UI_1_User.login;
import UI_2_Menu.rice;

public class AppDerivery1 {

 
    public static void main(String[] args) {
            
            login login = new login();
            login.setVisible(true);

            login login1 = new login();
            login1.setVisible(true);
                    
           // Designrice designricepage = new Designrice();
           // designricepage.setVisible(true);
            
           // Designnoodles designnoodlespage = new Designnoodles();
           // designnoodlespage.setVisible(true);
            
            //Designdrinks designdrinkpage = new Designdrinks();
            //designdrinkpage.setVisible(true);
            
           // Designdessert designdessertpage = new Designdessert();
           // designdessertpage.setVisible(true);
           
              //rice ricepage = new rice();
              //ricepage.setVisible(true);
              
             // drinks drinkpage = new drinks();
              //drinkpage.setVisible(true);
              
             // noodles noodlespage = new noodles();
             /// noodlespage.setVisible(true);
              
            //rice ricepage = new rice();
            //ricepage.setVisible(true);
              
          // Ordershistory ordershistorypage = new Ordershistory();
           //ordershistorypage.setVisible(true);
           
           //Admin adminpage = new Admin();
          //adminpage.setVisible(true);
              

           
}
}


