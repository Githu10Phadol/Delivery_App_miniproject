package UI_2_Menu;

import java.awt.Image;
import javax.swing.ImageIcon;

public class Designspecial extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Designspecial.class.getName());

    private String menuName;
    public Designspecial(String menuName) {
        initComponents();
        this.menuName = menuName;
        showMenuImage();
    }

    
    private void showMenuImage() {
        try {
            String imagePath = "src/rice/" + menuName + ".png";
            ImageIcon icon = new ImageIcon(imagePath);
            Image img = icon.getImage().getScaledInstance(imagespecial.getWidth(), imagespecial.getHeight(), Image.SCALE_SMOOTH);
            imagespecial.setIcon(new ImageIcon(img));
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Design = new javax.swing.JLabel();
        select = new javax.swing.JLabel();
        normal = new javax.swing.JRadioButton();
        special = new javax.swing.JRadioButton();
        addcart = new javax.swing.JButton();
        back = new javax.swing.JButton();
        imagespecial = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1280, 720));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(206, 215, 209));
        jPanel1.setPreferredSize(new java.awt.Dimension(1280, 720));
        jPanel1.setLayout(null);

        Design.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        Design.setText("ปรับแต่ง");
        jPanel1.add(Design);
        Design.setBounds(550, 50, 140, 40);

        select.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        select.setText("เลือกขนาด");
        jPanel1.add(select);
        select.setBounds(330, 120, 110, 29);

        normal.setBackground(new java.awt.Color(206, 215, 209));
        normal.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        normal.setText("ธรรมดา");
        normal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                normalActionPerformed(evt);
            }
        });
        jPanel1.add(normal);
        normal.setBounds(350, 170, 90, 30);

        special.setBackground(new java.awt.Color(206, 215, 209));
        special.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        special.setText("พิเศษ");
        special.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                specialActionPerformed(evt);
            }
        });
        jPanel1.add(special);
        special.setBounds(500, 170, 90, 30);

        addcart.setBackground(new java.awt.Color(217, 217, 217));
        addcart.setFont(new java.awt.Font("Tahoma", 1, 25)); // NOI18N
        addcart.setText("ใส่ตะกร้า");
        addcart.setBorder(null);
        addcart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addcartActionPerformed(evt);
            }
        });
        jPanel1.add(addcart);
        addcart.setBounds(500, 550, 220, 40);

        back.setBackground(new java.awt.Color(204, 204, 204));
        back.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Media/Back (4).png"))); // NOI18N
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        jPanel1.add(back);
        back.setBounds(50, 30, 18, 30);
        jPanel1.add(imagespecial);
        imagespecial.setBounds(80, 130, 150, 150);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void normalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_normalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_normalActionPerformed

    private void specialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_specialActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_specialActionPerformed

    private void addcartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addcartActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_addcartActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        rice ricePage = new rice();
        ricePage.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_backActionPerformed

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Design;
    private javax.swing.JButton addcart;
    private javax.swing.JButton back;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton normal;
    private javax.swing.JLabel select;
    private javax.swing.JRadioButton special;
    private javax.swing.JLabel imagespecial;
    // End of variables declaration//GEN-END:variables
}
