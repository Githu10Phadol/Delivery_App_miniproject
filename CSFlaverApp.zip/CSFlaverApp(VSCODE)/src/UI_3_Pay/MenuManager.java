package UI_3_Pay;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;

public class MenuManager{
    private static MenuManager instance;
    private HashMap<String, MenuData> menuMap;
    
    public static class MenuData {
        public String name;
        public int price;
        
        public MenuData(String name, int price) {
            this.name = name;
            this.price = price;
        }
    }
    
    private MenuManager() {
        menuMap = new HashMap<>();
        loadMenu();
    }
    
    public static MenuManager getInstance() {
        if (instance == null) {
            instance = new MenuManager();
        }
        return instance;
    }
    
    private void loadMenu() {
        try {
            BufferedReader br = new BufferedReader(new FileReader("src/datacsv/Menu.csv"));
            br.readLine();
            
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = splitCSV(line);
                
                if (parts.length >= 5) {
                    String menuName = parts[0];
                    int price = Integer.parseInt(parts[1]);
                    String imagePath = parts[4];
                    String key = getFileName(imagePath);
                    menuMap.put(key, new MenuData(menuName, price));
                }
            }
            br.close();
        } catch (Exception e) {
            System.out.println("Error loading menu: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private String[] splitCSV(String line) {
        String[] result = new String[5];
        int index = 0;
        boolean inQuotes = false;
        StringBuilder current = new StringBuilder();
        
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '"') {
                inQuotes = !inQuotes;
            } else if (c == ',' && !inQuotes) {
                result[index++] = current.toString().trim();
                current = new StringBuilder();
            } else {
                current.append(c);
            }
        }
        result[index] = current.toString().trim();
        return result;
    }
    
    private String getFileName(String path) {
        String[] parts = path.split("/");
        String file = parts[parts.length - 1];
        return file.replace(".png", "");
    }
    
    public MenuData getMenu(String key) {
        return menuMap.get(key);
    }
}