package UI_3_Pay;

import java.util.ArrayList;

public class CartManager {
    private static CartManager instance;
    private ArrayList<CartItem> items;
    
    public static class CartItem {
        private String menuName;
        private String imageName;
        private String size;
        private String meat;
        private String sweetness;
        private String noodle;
        private int price;
        private String category;
        
        public CartItem(String menuName, String imageName, String category, int basePrice) {
            this.menuName = menuName;
            this.imageName = imageName;
            this.category = category;
            this.price = basePrice;
        }
        
        public String getMenuName() { return menuName; }
        public String getImageName() { return imageName; }
        public String getSize() { return size; }
        public void setSize(String size) { this.size = size; }
        public String getMeat() { return meat; }
        public void setMeat(String meat) { this.meat = meat; }
        public String getSweetness() { return sweetness; }
        public void setSweetness(String sweetness) { this.sweetness = sweetness; }
        public String getNoodle() { return noodle; }
        public void setNoodle(String noodle) { this.noodle = noodle; }
        public int getPrice() { return price; }
        public void setPrice(int price) { this.price = price; }
        public String getCategory() { return category; }
        
        public String getDetails() {
            StringBuilder details = new StringBuilder(menuName);
            
            if (noodle != null && !noodle.isEmpty()) {
                details.append(" (").append(noodle);
                if (meat != null && !meat.isEmpty()) {
                    details.append(", ").append(meat);
                }
                if (size != null && !size.isEmpty()) {
                    details.append(", ").append(size);
                }
                details.append(")");
            } else if (meat != null && !meat.isEmpty()) {
                details.append(" (").append(meat);
                if (size != null && !size.isEmpty()) {
                    details.append(", ").append(size);
                }
                details.append(")");
            } else if (size != null && !size.isEmpty()) {
                details.append(" (").append(size).append(")");
            } else if (sweetness != null && !sweetness.isEmpty()) {
                details.append(" (").append(sweetness).append(")");
            }
            
            return details.toString();
        }
    }
    
    private CartManager() {
        items = new ArrayList<>();
    }
    
    public static CartManager getInstance() {
        if (instance == null) {
            instance = new CartManager();
        }
        return instance;
    }
    
    public void addItem(CartItem item) {
        items.add(item);
    }
    
    public void removeItem(int index) {
        if (index >= 0 && index < items.size()) {
            items.remove(index);
        }
    }
    
    public ArrayList<CartItem> getItems() {
        return items;
    }
    
    public int getTotalPrice() {
        int total = 0;
        for (CartItem item : items) {
            total += item.getPrice();
        }
        return total;
    }
    
    public void clearCart() {
        items.clear();
    }
    
    public int getItemCount() {
        return items.size();
    }
}